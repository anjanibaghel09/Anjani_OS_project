# Disk Scheduling Analyzer

Operating System algorithm simulator. **All calculations are done in C**; the browser (HTML/CSS/JS + Chart.js) only displays results.

Algorithms: FCFS, SSTF, SCAN, C-SCAN, LOOK, C-LOOK (one C file each in `backend/`).

## Structure
```
backend/   main.c (HTTP server, JSON, validation), fcfs.c sstf.c scan.c cscan.c look.c clook.c, algorithms.h
frontend/  index.html style.css script.js
Makefile   README.md
```

## Requirements
- `gcc` and `make` on Linux, macOS, or Windows via WSL / MSYS2 (the server uses POSIX sockets).
- A browser. Chart.js loads from a CDN, so the first load needs internet. For offline labs, download
  `chart.umd.min.js` into `frontend/` and change the `<script src>` in `index.html` to `chart.umd.min.js`.

## Compile and run
```
make          # compiles to ./disk_scheduler
make run      # starts the server on port 8080
```
Open **http://localhost:8080**. Stop with Ctrl+C. Custom path/port: `./disk_scheduler frontend 9000`.

## How it works
The browser sends `POST /api/analyze` with JSON:
`{"requests":[98,183,37],"head":53,"cylinders":200,"direction":"right"}`.
The C backend validates the input, removes duplicate requests (first occurrence kept), runs all six algorithms and returns
`total`, `average` (total / number of requests), `final`, `sequence` and `path` for each. The page updates without reloading.
Invalid input (request outside 0..cylinders-1, non-integers, empty queue, bad head) returns `{"error":"..."}`.

## Rules used
- SCAN and C-SCAN travel to the disk end (cylinder 0 or cylinders-1). LOOK and C-LOOK stop at the last request.
- The return jump of C-SCAN and C-LOOK **is counted** as head movement.
- FCFS and SSTF ignore the direction setting.

## Sample tests (head 53, 200 cylinders, queue `98,183,37,122,14,124,65,67`)
| Algorithm | Direction right | Direction left |
|---|---|---|
| FCFS | 640 | 640 |
| SSTF | 236 | 236 |
| SCAN | 331 | 236 |
| C-SCAN | 382 | 386 |
| LOOK | 299 | 208 |
| C-LOOK | 322 | 326 |

Average = total / 8 (e.g. FCFS 80.00, SSTF 29.50).

Duplicates: queue `10,10,20`, head 5, 50 cylinders, right -> 1 duplicate removed; FCFS/SSTF/LOOK/C-LOOK = 15, SCAN/C-SCAN = 44.

Error check: queue `10,500`, head 5, 50 cylinders -> "Request 500 is outside the disk (valid range 0 to 49)."

Command-line test (server running):
```
curl -s -X POST localhost:8080/api/analyze -d '{"requests":[98,183,37,122,14,124,65,67],"head":53,"cylinders":200,"direction":"right"}'
```
