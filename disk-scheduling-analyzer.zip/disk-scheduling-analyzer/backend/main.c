/* Disk Scheduling Analyzer - C backend.
   A tiny HTTP server: serves the frontend files and answers POST /api/analyze
   with JSON. All scheduling maths happens in the algorithm functions. */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "algorithms.h"

#define BUF 65536
static const struct { const char *id, *name; AlgoFn fn; } ALGOS[6] = {
    {"fcfs","FCFS",run_fcfs}, {"sstf","SSTF",run_sstf}, {"scan","SCAN",run_scan},
    {"cscan","C-SCAN",run_cscan}, {"look","LOOK",run_look}, {"clook","C-LOOK",run_clook}};

/* ---------- input parsing & validation ---------- */
static int parse_input(const char *b, int *req, int *n, int *head, int *cyl, int *dir, int *dups, char *err) {
    const char *p; char *e; int raw[4 * MAX_REQ], cnt = 0, i, j;
    p = strstr(b, "\"cylinders\"");
    if (!p || !(p = strchr(p, ':'))) { strcpy(err, "Total cylinders is missing."); return 0; }
    *cyl = (int)strtol(p + 1, &e, 10);
    if (e == p + 1) { strcpy(err, "Total cylinders must be a whole number."); return 0; }
    p = strstr(b, "\"head\"");
    if (!p || !(p = strchr(p, ':'))) { strcpy(err, "Initial head position is missing."); return 0; }
    *head = (int)strtol(p + 1, &e, 10);
    if (e == p + 1) { strcpy(err, "Initial head position must be a whole number."); return 0; }
    *dir = strstr(b, "\"left\"") ? DIR_LEFT : DIR_RIGHT;
    if (*cyl < 2 || *cyl > 100000) { strcpy(err, "Total cylinders must be between 2 and 100000."); return 0; }
    if (*head < 0 || *head >= *cyl) { sprintf(err, "Head position must be between 0 and %d.", *cyl - 1); return 0; }
    p = strstr(b, "\"requests\"");
    if (!p || !(p = strchr(p, '['))) { strcpy(err, "Request queue is missing."); return 0; }
    p++;
    while (*p == ' ') p++;
    while (*p != ']') {
        if (cnt >= 4 * MAX_REQ) { strcpy(err, "Too many requests."); return 0; }
        raw[cnt] = (int)strtol(p, &e, 10);
        if (e == p) { strcpy(err, "Requests must be whole numbers separated by commas."); return 0; }
        p = e; while (*p == ' ') p++;
        if (*p == ',') { p++; while (*p == ' ') p++; }
        else if (*p != ']') { strcpy(err, "Requests must be whole numbers separated by commas."); return 0; }
        cnt++;
    }
    if (cnt == 0) { strcpy(err, "Enter at least one disk request."); return 0; }
    for (i = 0; i < cnt; i++)
        if (raw[i] < 0 || raw[i] >= *cyl) {
            sprintf(err, "Request %d is outside the disk (valid range 0 to %d).", raw[i], *cyl - 1); return 0; }
    *n = 0;                                   /* drop duplicates, keep first occurrence */
    for (i = 0; i < cnt; i++) {
        for (j = 0; j < *n; j++) if (req[j] == raw[i]) break;
        if (j == *n) { if (*n >= MAX_REQ) { sprintf(err, "At most %d distinct requests are allowed.", MAX_REQ); return 0; }
                       req[(*n)++] = raw[i]; }
    }
    *dups = cnt - *n;
    return 1;
}

/* ---------- JSON output ---------- */
static void json_list(char *o, size_t *k, const int *a, int n) {
    int i; *k += sprintf(o + *k, "[");
    for (i = 0; i < n; i++) *k += sprintf(o + *k, i ? ",%d" : "%d", a[i]);
    *k += sprintf(o + *k, "]");
}
static void analyze(const char *body, char *o, int *status) {
    int req[MAX_REQ], n, head, cyl, dir, dups, a, i, j, plen, slen, total, path[MAX_PATH], seq[MAX_REQ], served[MAX_REQ];
    char err[128]; size_t k = 0;
    if (!parse_input(body, req, &n, &head, &cyl, &dir, &dups, err)) {
        *status = 400; sprintf(o, "{\"error\":\"%s\"}", err); return; }
    *status = 200;
    k += sprintf(o, "{\"head\":%d,\"cylinders\":%d,\"direction\":\"%s\",\"count\":%d,\"duplicatesRemoved\":%d,\"results\":[",
                 head, cyl, dir == DIR_LEFT ? "left" : "right", n, dups);
    for (a = 0; a < 6; a++) {
        plen = ALGOS[a].fn(req, n, head, cyl, dir, path);
        total = 0; for (i = 1; i < plen; i++) total += abs(path[i] - path[i - 1]);
        if (a == 0) { memcpy(seq, req, n * sizeof(int)); slen = n; }     /* FCFS: arrival order */
        else {                                                            /* others: requests in visit order */
            memset(served, 0, sizeof served); slen = 0;
            for (i = 0; i < plen; i++)
                for (j = 0; j < n; j++) if (!served[j] && req[j] == path[i]) { served[j] = 1; seq[slen++] = path[i]; }
        }
        k += sprintf(o + k, "%s{\"id\":\"%s\",\"name\":\"%s\",\"total\":%d,\"average\":%.2f,\"final\":%d,\"sequence\":",
                     a ? "," : "", ALGOS[a].id, ALGOS[a].name, total, (double)total / n, path[plen - 1]);
        json_list(o, &k, seq, slen);
        k += sprintf(o + k, ",\"path\":"); json_list(o, &k, path, plen);
        k += sprintf(o + k, "}");
    }
    sprintf(o + k, "]}");
}

/* ---------- tiny HTTP server ---------- */
static void send_all(int fd, const char *d, size_t len) {
    while (len > 0) { ssize_t w = write(fd, d, len); if (w <= 0) return; d += w; len -= w; }
}
static void respond(int fd, int code, const char *mime, const char *body, size_t len) {
    char h[256];
    int hl = snprintf(h, sizeof h, "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
                      code, code == 200 ? "OK" : code == 400 ? "Bad Request" : "Not Found", mime, len);
    send_all(fd, h, hl); send_all(fd, body, len);
}
static const char *mime_of(const char *p) {
    const char *x = strrchr(p, '.');
    if (!x) return "text/plain";
    if (!strcmp(x, ".html")) return "text/html; charset=utf-8";
    if (!strcmp(x, ".css"))  return "text/css";
    if (!strcmp(x, ".js"))   return "application/javascript";
    return "application/octet-stream";
}
static void serve_file(int fd, const char *root, const char *url) {
    char path[512], *data; FILE *f; long sz; char *q = strchr((char *)url, '?');
    if (q) *q = 0;
    if (strlen(url) > 300 || strstr(url, "..")) { respond(fd, 404, "text/plain", "Not found", 9); return; }
    snprintf(path, sizeof path, "%s%s", root, strcmp(url, "/") ? url : "/index.html");
    f = fopen(path, "rb");
    if (!f) { respond(fd, 404, "text/plain", "Not found", 9); return; }
    fseek(f, 0, SEEK_END); sz = ftell(f); rewind(f);
    data = malloc(sz + 1);
    if (data && fread(data, 1, sz, f) == (size_t)sz) respond(fd, 200, mime_of(path), data, sz);
    fclose(f); free(data);
}
static void handle(int fd, const char *root) {
    static char buf[BUF], out[BUF]; int got = 0, status; char *hdr_end = NULL, *cl; long clen = 0;
    while (got < BUF - 1) {
        ssize_t r = recv(fd, buf + got, BUF - 1 - got, 0);
        if (r <= 0) break;
        got += r; buf[got] = 0;
        if (!hdr_end && (hdr_end = strstr(buf, "\r\n\r\n"))) {
            cl = strcasestr(buf, "Content-Length:"); clen = cl ? atol(cl + 15) : 0; }
        if (hdr_end && got >= (hdr_end + 4 - buf) + clen) break;
    }
    if (!hdr_end) return;
    if (!strncmp(buf, "POST /api/analyze", 17)) {
        analyze(hdr_end + 4, out, &status);
        respond(fd, status, "application/json", out, strlen(out));
    } else if (!strncmp(buf, "GET ", 4)) {
        char *u = buf + 4, *sp = strchr(u, ' '); if (sp) *sp = 0;
        serve_file(fd, root, u);
    } else respond(fd, 404, "text/plain", "Not found", 9);
}
int main(int argc, char **argv) {
    const char *root = argc > 1 ? argv[1] : "frontend";
    int port = argc > 2 ? atoi(argv[2]) : 8080, srv = socket(AF_INET, SOCK_STREAM, 0), one = 1;
    struct sockaddr_in addr = {0};
    signal(SIGPIPE, SIG_IGN);
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    addr.sin_family = AF_INET; addr.sin_port = htons(port); addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if (bind(srv, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(srv, 8) < 0) { perror("server"); return 1; }
    printf("Disk Scheduling Analyzer running at http://localhost:%d  (Ctrl+C to stop)\n", port);
    for (;;) { int c = accept(srv, NULL, NULL); if (c < 0) continue; handle(c, root); close(c); }
}
