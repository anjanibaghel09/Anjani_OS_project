#include "algorithms.h"
/* SCAN: sweep to the disk end in the chosen direction, then reverse. */
int run_scan(const int *r, int n, int head, int cyl, int dir, int *path) {
    int s[MAX_REQ], len = 0, i;
    sorted_copy(r, n, s); path_add(path, &len, head);
    if (dir == DIR_RIGHT) {
        for (i = 0; i < n; i++)     if (s[i] >= head) path_add(path, &len, s[i]);
        path_add(path, &len, cyl - 1);
        for (i = n - 1; i >= 0; i--) if (s[i] < head) path_add(path, &len, s[i]);
    } else {
        for (i = n - 1; i >= 0; i--) if (s[i] <= head) path_add(path, &len, s[i]);
        path_add(path, &len, 0);
        for (i = 0; i < n; i++)     if (s[i] > head) path_add(path, &len, s[i]);
    }
    return len;
}
