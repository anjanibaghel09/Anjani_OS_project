#include "algorithms.h"
/* C-SCAN: sweep to the disk end, jump to the other end, sweep again
   in the same direction. The return jump is counted as head movement. */
int run_cscan(const int *r, int n, int head, int cyl, int dir, int *path) {
    int s[MAX_REQ], len = 0, i, rest = 0;
    sorted_copy(r, n, s); path_add(path, &len, head);
    if (dir == DIR_RIGHT) {
        for (i = 0; i < n; i++) { if (s[i] >= head) path_add(path, &len, s[i]); else rest++; }
        path_add(path, &len, cyl - 1);
        if (rest) { path_add(path, &len, 0);
            for (i = 0; i < n; i++) if (s[i] < head) path_add(path, &len, s[i]); }
    } else {
        for (i = n - 1; i >= 0; i--) { if (s[i] <= head) path_add(path, &len, s[i]); else rest++; }
        path_add(path, &len, 0);
        if (rest) { path_add(path, &len, cyl - 1);
            for (i = n - 1; i >= 0; i--) if (s[i] > head) path_add(path, &len, s[i]); }
    }
    return len;
}
