#include "algorithms.h"
/* C-LOOK: like C-SCAN, but only travels as far as the last request, then
   jumps to the furthest request on the other side. Jump is counted. */
int run_clook(const int *r, int n, int head, int cyl, int dir, int *path) {
    int s[MAX_REQ], len = 0, i; (void)cyl;
    sorted_copy(r, n, s); path_add(path, &len, head);
    if (dir == DIR_RIGHT) {
        for (i = 0; i < n; i++) if (s[i] >= head) path_add(path, &len, s[i]);
        for (i = 0; i < n; i++) if (s[i] < head)  path_add(path, &len, s[i]);
    } else {
        for (i = n - 1; i >= 0; i--) if (s[i] <= head) path_add(path, &len, s[i]);
        for (i = n - 1; i >= 0; i--) if (s[i] > head)  path_add(path, &len, s[i]);
    }
    return len;
}
