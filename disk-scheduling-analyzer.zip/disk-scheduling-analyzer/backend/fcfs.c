#include "algorithms.h"
/* FCFS: serve requests exactly in arrival order. */
int run_fcfs(const int *r, int n, int head, int cyl, int dir, int *path) {
    int len = 0, i; (void)cyl; (void)dir;
    path_add(path, &len, head);
    for (i = 0; i < n; i++) path_add(path, &len, r[i]);
    return len;
}
