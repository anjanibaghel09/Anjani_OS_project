#include "algorithms.h"
/* SSTF: always serve the pending request closest to the current head. */
int run_sstf(const int *r, int n, int head, int cyl, int dir, int *path) {
    int used[MAX_REQ] = {0}, len = 0, cur = head, k, i, best; (void)cyl; (void)dir;
    path_add(path, &len, head);
    for (k = 0; k < n; k++) {
        best = -1;
        for (i = 0; i < n; i++)
            if (!used[i] && (best < 0 || abs(r[i] - cur) < abs(r[best] - cur))) best = i;
        used[best] = 1; cur = r[best];
        path_add(path, &len, cur);
    }
    return len;
}
