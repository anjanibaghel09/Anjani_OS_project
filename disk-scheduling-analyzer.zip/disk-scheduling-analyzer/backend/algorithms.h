#ifndef ALGORITHMS_H
#define ALGORITHMS_H
#include <stdlib.h>
#include <string.h>

#define MAX_REQ  200
#define MAX_PATH (MAX_REQ + 8)
#define DIR_LEFT  0
#define DIR_RIGHT 1

/* Every algorithm fills `path` with the head positions visited (starting with
   the initial head position) and returns the number of positions. */
typedef int (*AlgoFn)(const int *r, int n, int head, int cyl, int dir, int *path);

int run_fcfs (const int *r, int n, int head, int cyl, int dir, int *path);
int run_sstf (const int *r, int n, int head, int cyl, int dir, int *path);
int run_scan (const int *r, int n, int head, int cyl, int dir, int *path);
int run_cscan(const int *r, int n, int head, int cyl, int dir, int *path);
int run_look (const int *r, int n, int head, int cyl, int dir, int *path);
int run_clook(const int *r, int n, int head, int cyl, int dir, int *path);

/* Append a head position (ignores a repeat of the previous position). */
static inline void path_add(int *path, int *len, int v) {
    if (*len == 0 || path[*len - 1] != v) path[(*len)++] = v;
}
static int cmp_int(const void *a, const void *b) { return *(const int *)a - *(const int *)b; }
static inline void sorted_copy(const int *r, int n, int *s) {
    memcpy(s, r, n * sizeof(int));
    qsort(s, n, sizeof(int), cmp_int);
}
#endif
