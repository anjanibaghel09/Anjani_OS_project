const $ = id => document.getElementById(id);
const CY = '#22d3ee', PU = '#a78bfa', GO = '#fbbf24';
let moveChart, cmpChart, data;

function showError(msg) { $('error').textContent = msg; $('error').hidden = !msg; }

async function fetchAll() {
  showError('');
  const tokens = $('queue').value.split(/[\s,]+/).filter(Boolean);
  const requests = tokens.map(Number);
  if (!tokens.length || requests.some(x => !Number.isInteger(x))) { showError('Enter the request queue as whole numbers separated by commas.'); return null; }
  const body = { requests, head: parseInt($('head').value, 10), cylinders: parseInt($('cyl').value, 10), direction: $('dir').value };
  if (Number.isNaN(body.head) || Number.isNaN(body.cylinders)) { showError('Head position and total cylinders must be whole numbers.'); return null; }
  try {
    const res = await fetch('/api/analyze', { method: 'POST', body: JSON.stringify(body) });
    const json = await res.json();
    if (json.error) { showError(json.error); return null; }
    return json;
  } catch (e) { showError('Cannot reach the C backend. Start it with "make run" and open http://localhost:8080.'); return null; }
}

const arrows = { id: 'arrows', afterDatasetsDraw(c) {
  const m = c.getDatasetMeta(0), d = c.data.datasets[0].data, ctx = c.ctx;
  ctx.save(); ctx.font = '12px Segoe UI, sans-serif'; ctx.textAlign = 'center';
  m.data.forEach((p, i) => {
    ctx.fillStyle = '#e6eefc'; ctx.fillText(d[i], p.x, p.y - 11);
    if (!i) return;
    const q = m.data[i - 1]; ctx.save();
    ctx.translate((p.x + q.x) / 2, (p.y + q.y) / 2); ctx.rotate(Math.atan2(p.y - q.y, p.x - q.x));
    ctx.fillStyle = d[i] >= d[i - 1] ? CY : PU;
    ctx.beginPath(); ctx.moveTo(7, 0); ctx.lineTo(-5, -5); ctx.lineTo(-5, 5); ctx.fill(); ctx.restore();
  });
  ctx.restore();
} };

function renderAnalyzer() {
  const r = data.results.find(x => x.id === $('algo').value);
  const stats = [['Selected algorithm', r.name], ['Initial head position', data.head], ['Total head movement', r.total],
    ['Average head movement', r.average.toFixed(2)], ['Number of requests', data.count + (data.duplicatesRemoved ? ` (${data.duplicatesRemoved} duplicate removed)` : '')], ['Final head position', r.final]];
  $('cards').innerHTML = stats.map(s => `<div class="stat"><span>${s[0]}</span><b>${s[1]}</b></div>`).join('');
  $('seq').innerHTML = `<span class="chip start">${data.head} (start)</span>` + r.sequence.map(v => `<span class="chip">${v}</span>`).join('');
  $('results').hidden = false;
  if (moveChart) moveChart.destroy();
  moveChart = new Chart($('moveChart'), { type: 'line', plugins: [arrows],
    data: { labels: r.path.map((_, i) => i), datasets: [{ data: r.path, borderColor: CY, borderWidth: 2.5, tension: 0,
      pointRadius: r.path.map((_, i) => i ? 5 : 8), pointBackgroundColor: r.path.map((_, i) => i ? '#e6eefc' : GO),
      segment: { borderColor: c => c.p1.parsed.y >= c.p0.parsed.y ? CY : PU } }] },
    options: { maintainAspectRatio: false, layout: { padding: { top: 18 } }, plugins: { legend: { display: false } },
      scales: { x: { title: { display: true, text: 'Request processing order (0 = start)', color: '#8fa3c8' }, ticks: { color: '#8fa3c8' }, grid: { color: '#1d2f5c' } },
        y: { min: 0, max: data.cylinders - 1, title: { display: true, text: 'Cylinder number', color: '#8fa3c8' }, ticks: { color: '#8fa3c8' }, grid: { color: '#1d2f5c' } } } } });
}

function renderComparison() {
  const min = Math.min(...data.results.map(r => r.total));
  $('cmpBody').innerHTML = data.results.map(r => `<tr class="${r.total === min ? 'best' : ''}"><td>${r.name}</td><td>${r.total}</td><td>${r.average.toFixed(2)}</td></tr>`).join('');
  $('cmp').hidden = false;
  if (cmpChart) cmpChart.destroy();
  cmpChart = new Chart($('cmpChart'), { type: 'bar',
    data: { labels: data.results.map(r => r.name), datasets: [{ data: data.results.map(r => r.total),
      backgroundColor: data.results.map(r => r.total === min ? CY : '#4c3f91'), borderRadius: 8 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } },
      scales: { x: { ticks: { color: '#8fa3c8' }, grid: { display: false } }, y: { beginAtZero: true, ticks: { color: '#8fa3c8' }, grid: { color: '#1d2f5c' } } } } });
}

function syncDirection() { $('dir').disabled = ['fcfs', 'sstf'].includes($('algo').value); }

$('calc').onclick = async () => { const d = await fetchAll(); if (d) { data = d; renderAnalyzer(); renderComparison(); } };
$('compare').onclick = async () => { const d = await fetchAll(); if (d) { data = d; renderAnalyzer(); renderComparison(); } };
$('algo').onchange = () => { syncDirection(); if (data) renderAnalyzer(); };
$('reset').onclick = () => {
  $('queue').value = '98, 183, 37, 122, 14, 124, 65, 67'; $('head').value = 53; $('cyl').value = 200;
  $('dir').value = 'right'; $('algo').value = 'fcfs'; syncDirection(); showError('');
  $('results').hidden = true; $('cmp').hidden = true; data = null;
};
syncDirection();
